import numpy as np
from sensitivity_parallel import Grids_parallel, Model_parallel
from Observe import observe_data
import time
from Fig_2D import Fig_xy
import matplotlib.pyplot as plt


t1 = time.time()

GraModel = Grids_parallel(0, 100, 4000,
                          0, 100, 4000,
                          None, 0,
                          0, 100, 4000,
                          0, 100, 4000,
                          0, 100, 2000)
model = Model_parallel(GraModel)

model.property[5:15, 18:22, 5:10] = 1
model.property[25:35, 18:22, 5:10] = 1

model.forward()

# 结束计时
t2 = time.time()
print("正演耗时：", t2 - t1)
# ---------------------------结束正演计算---------------------------------------------

print('模型规模量：', model.property.shape)
print('model.anomaly.shape = ', model.anomaly.shape)
print('max = ', model.anomaly.max())
print('min = ', model.anomaly.min())

data = observe_data(100, 100, model.anomaly)
np.savetxt('./data/重力数据1.txt', data)

# ---------------------------可视化---------------------------------------------
Fig_xy(100, model.anomaly, 0.1, 0.1, 'mGal', 0)

plt.show()
