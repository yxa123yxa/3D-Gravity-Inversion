from dataio import loader
import numpy as np
from sensitivity_trad import Grids_trad, Model_trad
from sensitivity_parallel import Grids_parallel, Model_parallel
import time


def focus_cginv(path, Z_obs, reference, opt_s, m_max, m_min, epochs, error, z_start, z_step, z_end, alpha, e, T):

    input = loader(path)
    d_grid = input.data

    if opt_s == "trad":
        GraModel = Grids_trad(input.x_start, input.x_step, input.x_end,
                         input.y_start, input.y_step, input.y_end,
                         None, Z_obs,
                         input.x_start, input.x_step, input.x_end,
                         input.y_start, input.y_step, input.y_end,
                         z_start, z_step, z_end)
        model = Model_trad(GraModel)
    else:
        GraModel = Grids_parallel(input.x_start, input.x_step, input.x_end,
                         input.y_start, input.y_step, input.y_end,
                         None, Z_obs,
                         input.x_start, input.x_step, input.x_end,
                         input.y_start, input.y_step, input.y_end,
                         z_start, z_step, z_end)
        model = Model_parallel(GraModel)

    nx, ny, nz = GraModel.x_model_num, GraModel.y_model_num, GraModel.z_model_num
    # 初始化
    if reference == 0:
        m_ref = np.zeros((nx, ny, nz))
        Ww = np.ones((nx, ny, nz))
    else:
        m_ref = np.load('./data/初始模型.npy')
        Ww = np.load('./data/权重矩阵.npy')
        m_control = np.load('./data/映射模型.npy')

    m0 = m_ref.copy()
    We = 1/np.sqrt(m0**2+e**2)
    grad, Wm, loss, Loss = model.iter_grad0(d_grid, m0, m_ref, Ww, We, alpha)

    # # 另一种深度加权函数
    # Wm = np.zeros((nx, ny, nz))
    # for k in range(nz):
    #     val = 1.0 / ((k + 1) * z_step + np.abs(Z_obs)) ** 0.75
    #     Wm[:, :, k] = val

    mw = Wm * We * m0
    m = m0.copy()
    f = grad.copy()
    d = f.copy()
    ff = np.sum(f*f)
    t_up = np.sum(d*f)
    t_down = model.iter_t_down(d, Wm, We, alpha)
    t = t_up / (t_down + 1e-16)

    # 预处理时间
    T2 = time.time()
    print('预处理时间：', T2 - T)

    count = 0
    while loss > error and count < epochs:
        count += 1
        mw -= t * d
        m = mw / (Wm*We)

        # -------------------------------------------------
        m[m > m_max] = m_max
        m[m < m_min] = m_min
        m = m*m_control
        # -------------------------------------------------

        We = 1 / np.sqrt(m ** 2 + e ** 2)

        mw = Wm * We * m

        # --------------可选择使用自适应迭代---------------------
        # if count == 1:
        #     alpha_up = np.sum(Loss)
        #     alpha_down = np.sum((m) ** 2)
        #     alpha = 1 * alpha_up / alpha_down
        #     print("alpha_0 =", alpha)
        # else:
        #     alpha = 0.8*alpha
        # -----------------------------------------------------

        grad, loss = model.iter_grad(d_grid, m, m_ref, Wm, We, alpha)
        print('Iter: {}  Loss: {}'.format(count, loss))

        f = grad.copy()
        beta = np.sum(f**2)/(ff+1e-16)
        d = f + beta*d
        ff = np.sum(f**2)
        t_up = np.sum(d*f)
        t_down = model.iter_t_down(d, Wm, We, alpha)
        t = t_up / (t_down + 1e-16)
    return m
