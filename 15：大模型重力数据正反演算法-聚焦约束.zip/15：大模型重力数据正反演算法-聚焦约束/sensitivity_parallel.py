import numpy as np
from numba import njit, prange
from concurrent.futures import ProcessPoolExecutor

# --------------------------- 核心计算 ---------------------------
G0 = 6.67259

@njit
def dg_numba(xd, yd, zd):
    r = np.sqrt(xd**2 + yd**2 + zd**2) + 1e-16
    gx = np.log(r - yd) if r != yd else 0.0
    gy = np.log(r - xd) if r != xd else 0.0
    gz = np.arctan(xd * yd / (r * zd + 1e-16))
    if np.isnan(gx) or np.isinf(gx):
        gx = 0.0
    if np.isnan(gy) or np.isinf(gy):
        gy = 0.0
    if np.isnan(gz) or np.isinf(gz):
        gz = 0.0
    return xd * gx + yd * gy + zd * gz


# --------------------------- 网格类 ---------------------------
class Grids_parallel:
    def __init__(self,
                 x_measure_start, x_measure_step, x_measure_end,
                 y_measure_start, y_measure_step, y_measure_end,
                 z_measure_square, z_measure,
                 x_model_start, x_model_step, x_model_end,
                 y_model_start, y_model_step, y_model_end,
                 z_model_start, z_model_step, z_model_end):
        self.x_measure = np.arange(x_measure_start, x_measure_end + 0.001, x_measure_step) / 1000
        self.y_measure = np.arange(y_measure_start, y_measure_end + 0.001, y_measure_step) / 1000
        self.x_measure_num = len(self.x_measure)
        self.y_measure_num = len(self.y_measure)
        self.x_model = np.arange(x_model_start, x_model_end + 0.001, x_model_step) / 1000
        self.y_model = np.arange(y_model_start, y_model_end + 0.001, y_model_step) / 1000
        self.z_model = np.arange(z_model_start, z_model_end + 0.001, z_model_step) / 1000
        self.x_model_num = len(self.x_model) - 1
        self.y_model_num = len(self.y_model) - 1
        self.z_model_num = len(self.z_model) - 1
        self.z_measure_square = np.zeros((self.x_measure_num, self.y_measure_num))
        self.z_measure = 0 if z_measure is None else z_measure / 1000
        if z_measure_square is not None:
            self.z_measure_square = z_measure_square / 1000


# --------------------------- 灵敏度计算函数 ---------------------------
@njit(parallel=True)
def compute_sensitivity_base_numba(x_model, y_model, z_model, z_measure):
    nx, ny, nz = len(x_model)-1, len(y_model)-1, len(z_model)-1
    s_temp = np.zeros((nx+1, ny+1, nz+1))
    for i in prange(nx+1):
        for j in prange(ny+1):
            for k in prange(nz+1):
                xd = x_model[i]
                yd = y_model[j]
                zd = z_model[k] - z_measure
                s_temp[i,j,k] = dg_numba(xd, yd, zd)
    s_temp2 = (s_temp[1:,1:,1:] + s_temp[0:-1,0:-1,1:] +
               s_temp[0:-1,1:,0:-1] + s_temp[1:,0:-1,0:-1] -
               s_temp[0:-1,1:,1:] - s_temp[1:,0:-1,1:] -
               s_temp[1:,1:,0:-1] - s_temp[0:-1,0:-1,0:-1])
    s_flipr = np.concatenate((np.fliplr(s_temp2), s_temp2), axis=1)
    s_flipud = np.concatenate((np.flipud(s_flipr), s_flipr), axis=0)
    return s_flipud * G0, nx, ny, 2*nx, 2*ny


# --------------------------- 提取灵敏度的函数 ---------------------------
@njit
def extract_sensitivity_numba(sensitivity_base, xmid, ymid, xlen, ylen, ix, iy):
    """
    从灵敏度矩阵中提取局部灵敏度
    """
    return sensitivity_base[(xmid-ix):(xlen-ix),(ymid-iy):(ylen-iy),:]


# --------------------------- 正演和梯度计算函数 ---------------------------
@njit(parallel=True)
def forward_numba(property, sensitivity_base, xmid, ymid, xlen, ylen, nx_measure, ny_measure):
    anomaly = np.zeros((nx_measure, ny_measure))
    for i in prange(nx_measure):
        for j in prange(ny_measure):
            sens = extract_sensitivity_numba(sensitivity_base, xmid, ymid, xlen, ylen, i, j)
            anomaly[i,j] = np.sum(sens * property)
    return anomaly


# --------------------------- 梯度计算方法 ---------------------------
@njit(parallel=True)
def iter_grad0_numba(data_measure, m_property, m_ref, Ww, We, alpha, sensitivity_base, xmid, ymid, xlen, ylen):
    grad = np.zeros_like(m_property)
    Wm = np.zeros_like(m_property)
    loss = 0.0
    nx_measure, ny_measure = data_measure.shape
    for i in prange(nx_measure):
        for j in prange(ny_measure):
            sens = extract_sensitivity_numba(sensitivity_base, xmid, ymid, xlen, ylen, i, j)
            d_err = np.sum(sens * m_property) - data_measure[i,j]
            grad += sens * d_err
            Wm += sens * sens
            loss += d_err**2
    Wm = Wm ** 0.5 * Ww
    grad = grad / (Wm*We) + alpha * Wm * We* (m_property - m_ref)
    Loss = np.sqrt(loss / (nx_measure * ny_measure))
    return grad, Wm, loss, Loss


@njit(parallel=True)
def iter_grad_numba(data_measure, m_property, m_ref, W_height, We, alpha, sensitivity_base, xmid, ymid, xlen, ylen):
    grad = np.zeros_like(m_property)
    loss = 0.0
    nx_measure, ny_measure = data_measure.shape
    for i in prange(nx_measure):
        for j in prange(ny_measure):
            sens = extract_sensitivity_numba(sensitivity_base, xmid, ymid, xlen, ylen, i, j)
            d_err = np.sum(sens * m_property) - data_measure[i,j]
            grad += sens * d_err
            loss += d_err**2
    grad = grad / (W_height*We) + alpha * W_height * We* (m_property - m_ref)
    loss = np.sqrt(loss / (nx_measure*ny_measure))
    return grad, loss


# --------------------------- `iter_t_down` 计算 ---------------------------
@njit(parallel=True)
def iter_t_down_numba(p, Wm, We, alpha, sensitivity_base, xmid, ymid, xlen, ylen, nx_measure, ny_measure):
    vector = np.zeros((nx_measure, ny_measure))
    for i in prange(nx_measure):
        for j in prange(ny_measure):
            sens = extract_sensitivity_numba(sensitivity_base, xmid, ymid, xlen, ylen, i, j)
            vector[i,j] = np.sum(sens * p / Wm/ We)
    return np.sum(vector**2) + alpha * np.sum(p**2)


# --------------------------- 模型类 ---------------------------
class Model_parallel:
    def __init__(self, Grids):
        self.Grids = Grids
        self.nx, self.ny, self.nz = Grids.x_model_num, Grids.y_model_num, Grids.z_model_num
        self.property = np.zeros((self.nx, self.ny, self.nz))
        self.anomaly = np.zeros((Grids.x_measure_num, Grids.y_measure_num))
        self.sensitivity_base, self.xmid, self.ymid, self.xlen, self.ylen = compute_sensitivity_base_numba(
            Grids.x_model, Grids.y_model, Grids.z_model, Grids.z_measure
        )

    def forward(self):
        self.anomaly = forward_numba(self.property, self.sensitivity_base,
                                     self.xmid, self.ymid, self.xlen, self.ylen,
                                     self.Grids.x_measure_num, self.Grids.y_measure_num)

    def iter_grad0(self, data_measure, m_property, m_ref, Ww, We, alpha):
        return iter_grad0_numba(data_measure, m_property, m_ref, Ww, We, alpha,
                                self.sensitivity_base, self.xmid, self.ymid, self.xlen, self.ylen)

    def iter_grad(self, data_measure, m_property, m_ref, W_height, We, alpha):
        return iter_grad_numba(data_measure, m_property, m_ref, W_height, We, alpha,
                               self.sensitivity_base, self.xmid, self.ymid, self.xlen, self.ylen)

    def iter_t_down(self, p, Wm, We, alpha):
        return iter_t_down_numba(p, Wm, We, alpha,
                                  self.sensitivity_base, self.xmid, self.ymid, self.xlen, self.ylen,
                                  self.Grids.x_measure_num, self.Grids.y_measure_num)


if __name__ == "__main__":

    import time
    import matplotlib.pyplot as plt
    from Tool.Fig_2D import Fig_xy

    # ---------------------------开始正演计算---------------------------------------------
    t1 = time.time()

    GraModel = Grids_parallel(0, 100, 100*100,
                              0, 100, 100*100,
                              None, 0,
                              0, 100, 100*100,
                              0, 100, 100*100,
                              0, 100, 5000)

    model = Model_parallel(GraModel)
    model.property[50:60, 50:60, 10:20] = 1

    model.forward()

    # 结束计时
    t2 = time.time()
    print("正演耗时：", t2 - t1)
    # ---------------------------结束正演计算---------------------------------------------

    print('模型规模量：', model.property.shape)
    print('model.anomaly.shape = ', model.anomaly.shape)
    print('max = ', model.anomaly.max())
    print('min = ', model.anomaly.min())

    # ---------------------------可视化---------------------------------------------
    Fig_xy(100, model.anomaly, 0.1, 0.1, 'mGal', 0)

    # plt.savefig('./figure/gra_1_anomaly', dpi=300)

    plt.show()
