import numpy as np
from CG_focus import focus_cginv
import time
import matplotlib.pyplot as plt
from Fig_2D import Fig_xz, Fig_xy, line


# -------------------------------反演参数设置------------------------------------------
path = 'data/重力数据1.txt'           # 观测数据
Z_obs = 0                            # 观测平面
reference = 0                        # 0/1
option = "parallel"                  # trad/parallel
m_max = 1                            # 密度上限
m_min = -1                            # 密度下限
epochs = 200                         # 迭代次数
error = 0                            # 截止误差
z_step = 100                         # 垂向单元长度
z_end = 2000                         # 最大反演深度
alpha = 0.01
e = 0.01

# -------------------------------反演开始-----------------------------------------------
T1 = time.time()
result = focus_cginv(path, Z_obs, reference, option, m_max, m_min, epochs, error, z_step, z_end, alpha, e, T1)
T2 = time.time()

# -------------------------------反演结束-----------------------------------------------
print("反演总耗时：", T2 - T1)
print("模型形状：", result.shape)

np.save('./data/重力数据1_inv.npy', result)

# -------------------------------反演结果可视化--------------------------------------------
Fig_xz(100, result[:, 20, :].T, 0.1, 0.1, 'gra', 'upper')
X, Y = 40, 20
lw = '2.0'
ls = '-'
color = 'white'
x1, x2, y1, y2 = 5, 15, 5, 10
line(X, Y, x1, x2, y1, y2, color, lw, ls)
x1, x2, y1, y2 = 25, 35, 5, 10
line(X, Y, x1, x2, y1, y2, color, lw, ls)

plt.show()
