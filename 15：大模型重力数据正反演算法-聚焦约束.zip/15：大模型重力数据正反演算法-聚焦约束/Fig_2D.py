import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits import axes_grid1
import matplotlib


def addColorbar(image, aspect=20, pad_fraction=1, **kwargs):
    """Add a vertical color bar to an image plot."""
    divider = axes_grid1.make_axes_locatable(image.axes)
    width = axes_grid1.axes_size.AxesY(image.axes, aspect=1. / aspect)
    pad = axes_grid1.axes_size.Fraction(pad_fraction, width)
    current_ax = plt.gca()
    cax = divider.append_axes("right", size=width, pad=pad)
    plt.sca(current_ax)
    return image.axes.figure.colorbar(image, cax=cax, **kwargs)


def line(X, Y, x1, x2, y1, y2, color, lw, ls):

    plt.axvline(x=x1-0.5, ymin=(Y - y2) / Y, ymax=(Y - y1) / Y, color=color, lw=lw, ls=ls)
    plt.axvline(x=x2-0.5, ymin=(Y - y2) / Y, ymax=(Y - y1) / Y, color=color, lw=lw, ls=ls)
    plt.axhline(y=y1-0.5, xmin=x1 / X, xmax=x2 / X, color=color, lw=lw, ls=ls)
    plt.axhline(y=y2-0.5, xmin=x1 / X, xmax=x2 / X, color=color, lw=lw, ls=ls)


def model_boundary(X, Y, lst):
    lw = '1.5'
    ls = '-'
    color = 'black'
    x1, x2, y1, y2 = lst
    line(X, Y, x1, x2, y1, y2, color, lw, ls)


def Fig_xz(num, Data, X_interval, Y_interval, string, origin):
    [y, x] = Data.shape
    x_interval = x/4
    y_interval = y/4
    plt.figure(num)
    plt.rcParams['font.family'] = ['Times New Roman']
    plt.rcParams['font.weight'] = 'bold'
    # subfig = plt.imshow(Data, cmap='jet', origin=origin,
    #                     norm=matplotlib.colors.Normalize(vmin=-np.max(abs(Data)), vmax=np.max(abs(Data))),
    #                     interpolation='bicubic', aspect='auto')
    subfig = plt.imshow(Data, cmap='jet', origin=origin,
                        norm=matplotlib.colors.Normalize(vmin=np.min(Data), vmax=np.max(Data)), interpolation='bicubic')
    # subfig = plt.contourf(Data, cmap='jet', origin=origin,
    #                      norm=matplotlib.colors.Normalize(vmin=-np.max(abs(Data)), vmax=np.max(abs(Data))))
    plt.ylabel('Z (km)', fontsize=20, fontweight='bold')
    ytickindex = []
    for i in range(1,5):
        ytickindex.append(y_interval*i-1)
    ytickindex.insert(0, 0)
    ylabel = [round(((i+1) * Y_interval), 1) for i in ytickindex]
    ylabel[0] = 0
    plt.yticks(ytickindex, labels=ylabel, fontsize=15)
    plt.xlabel('X (km)', fontsize=20, fontweight='bold')
    xtickindex = []
    for i in range(1, 5):
        xtickindex.append(x_interval * i -1)
    xtickindex.insert(0, 0)
    xlabel = [round(((i+1) * X_interval), 1) for i in xtickindex]
    xlabel[0] = 0
    plt.xticks(xtickindex, labels=xlabel, fontsize=15)
    clb = addColorbar(subfig)
    clb.ax.tick_params(labelsize=12)
    if string == 'mGal':
        clb.ax.set_title('mGal', fontsize=15, fontweight='bold')
    if string == 'nT':
        clb.ax.set_title('nT', fontsize=15, fontweight='bold')
    if string == 'gra':
        clb.ax.set_title('g/$\mathregular{cm^3}$', fontsize=15, fontweight='bold')
    if string == 'mag':
        clb.ax.set_title('A/m', fontweight='bold')
    if string == '':
        clb.ax.set_title('')
    plt.tight_layout()


def Fig_xy(num, Data, X_interval, Y_interval, string, round_num):
    [x, y] = Data.shape
    x_interval = int((x)/4)
    y_interval = int((y)/4)
    plt.figure(num)
    plt.rcParams['font.family'] = ['Times New Roman']
    plt.rcParams['font.weight'] = 'bold'
    if string == 'm':
        subfig = plt.imshow(Data.T, cmap='terrain', origin='lower',
                            norm=matplotlib.colors.Normalize(vmin=np.min(Data), vmax=np.max(Data)),
                            interpolation='bicubic', aspect='auto')
    else:
        subfig = plt.imshow(Data.T, cmap='jet', origin='lower',
                            norm=matplotlib.colors.Normalize(vmin=np.min(Data), vmax=np.max(Data)),
                            interpolation='bicubic', aspect='auto')
    plt.ylabel('Y (km)', fontsize=20, fontweight='bold')
    ytickindex = [0]
    for i in range(1,5):
        ytickindex.append(y_interval*i-1)
    if round_num == 0:
        ylabel = [int((i + 1) * Y_interval) for i in ytickindex]
    if round_num == 1:
        ylabel = [round((i + 1) * Y_interval, round_num) for i in ytickindex]
    ylabel[0] = 0
    plt.yticks(ytickindex, labels=ylabel, fontsize=15)
    plt.xlabel('X (km)', fontsize=20, fontweight='bold')
    xtickindex = [0]
    for i in range(1, 5):
        xtickindex.append(x_interval * i - 1)
    if round_num == 0:
        xlabel = [int((i + 1) * X_interval) for i in xtickindex]
    if round_num == 1:
        xlabel = [round((i + 1) * X_interval, round_num) for i in xtickindex]
    xlabel[0] = 0
    plt.xticks(xtickindex, labels=xlabel, fontsize=15)
    clb = addColorbar(subfig)
    clb.ax.tick_params(labelsize=12)
    if string == 'mGal':
        clb.ax.set_title('mGal', fontsize=15, fontweight='bold')
    if string == 'nT':
        clb.ax.set_title('nT', fontsize=15, fontweight='bold')
    if string == 'gra':
        clb.ax.set_title('g/$\mathregular{cm^3}$', fontsize=15, fontweight='bold')
    if string == 'mag':
        clb.ax.set_title('SI', fontsize=15, fontweight='bold')
    if string == 'm':
        clb.ax.set_title('m', fontsize=15, fontweight='bold')
    plt.tight_layout()
