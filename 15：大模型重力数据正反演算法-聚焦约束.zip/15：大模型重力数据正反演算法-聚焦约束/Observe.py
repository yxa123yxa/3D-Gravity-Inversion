import numpy as np


def observe_data(x_interval, y_interval, data):
    count = 0
    m = data.shape[0]
    n = data.shape[1]
    Data = np.zeros((m*n, 3))
    for j in range(n):
        for i in range(m):

            Data[count, 0] = i*x_interval      # x-axis
            Data[count, 1] = j*y_interval       # y-axis
            Data[count, 2] = data[i, j]
            count = count+1

    return Data
