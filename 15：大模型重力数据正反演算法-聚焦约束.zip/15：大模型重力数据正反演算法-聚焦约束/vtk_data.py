import numpy as np
import pyvtk
# from terrage import terrage_terrain


class Vtk_Model():

    def __init__(self,
                 x_model_start, x_model_step, x_model_end,
                 y_model_start, y_model_step, y_model_end,
                 z_model_start, z_model_step, z_model_end,
                 Z, name):

        self.x_model = np.arange(x_model_start, x_model_end + 0.1, x_model_step)
        self.y_model = np.arange(y_model_start, y_model_end + 0.1, y_model_step)
        self.z_model = np.arange(z_model_start, z_model_end + 0.1, z_model_step)-0.001
        self.Z = Z
        self.z_model_step = z_model_step
        self.z_model_end = z_model_end
        self.name = name
        self.x_grid_model, self.y_grid_model,  self.z_grid_model = len(self.x_model) - 1, len(self.y_model) - 1, len(self.z_model) - 1
        self.model_num = self.x_grid_model * self.y_grid_model * self.z_grid_model
        self.property = np.zeros((self.x_grid_model, self.y_grid_model, self.z_grid_model))

    def compute_point_cell1(self):

        self.List = []
        self.Index = np.zeros((self.model_num,8))
        index = np.array([0,1,2,3,4,5,6,7])
        step = 0
        Z1 = self.Z.T

        derta_Z = (self.z_model_end - self.Z.T) / self.z_grid_model
        for k in range(self.z_grid_model):
            Z2 = Z1 + derta_Z
            for j in range(self.y_grid_model):
                y1, y2 = self.y_model[j], self.y_model[j + 1]
                for i in range(self.x_grid_model):
                    x1, x2 = self.x_model[i], self.x_model[i + 1]
                    z1, z2, z3, z4, z5, z6, z7, z8 = Z1[i, j], Z1[i, j + 1], Z1[i + 1, j + 1], Z1[i + 1, j], Z2[i, j],\
                                                     Z2[i, j + 1], Z2[i + 1, j + 1], Z2[i + 1, j]
                    list = [[x1, y1, z1], [x1, y2, z2], [x2, y2, z3], [x2, y1, z4], [x1, y1, z5], [x1, y2, z6],
                            [x2, y2, z7], [x2, y1, z8]]
                    self.List.extend(list)
                    self.Index[step, :] = index
                    step = step+1
                    index = index + 8
            Z1 = Z2

        self.hexahedrons = self.Index.astype(int)

    def generate_vtk(self):
        self.cell_values = self.property.reshape((self.model_num,), order='F')
        self.compute_point_cell1()
        self.unstructured_grid = pyvtk.UnstructuredGrid(self.List, hexahedron=self.hexahedrons)
        self.cell_data = pyvtk.CellData(pyvtk.Scalars(self.cell_values, name='SI'))
        self.vtk_data = pyvtk.VtkData(self.unstructured_grid, self.cell_data)
        self.vtk_data.tofile(self.name)
