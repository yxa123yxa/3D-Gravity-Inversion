import numpy as np
from CG_focus import focus_cginv
import time
import matplotlib.pyplot as plt
from Fig_2D import Fig_xz, Fig_xy, line


# -------------------------------反演参数设置------------------------------------------
path = 'data/均衡重力_obs.txt'           # 观测数据
Z_obs = -5000                            # 观测平面
reference = 1                        # 0/1
option = "parallel"                  # trad/parallel
m_max = 0.6                            # 密度上限
m_min = -0.6                            # 密度下限
epochs = 200                         # 迭代次数
error = 0                            # 截止误差
z_start = -3000
z_step = 1000                         # 垂向单元长度
z_end = 1000*30                        # 最大反演深度
alpha = 0.01
e = 0.01

# -------------------------------反演开始-----------------------------------------------
T1 = time.time()
result = focus_cginv(path, Z_obs, reference, option, m_max, m_min, epochs, error, z_start, z_step, z_end, alpha, e, T1)
T2 = time.time()

# -------------------------------反演结束-----------------------------------------------
print("反演总耗时：", T2 - T1)
print("模型形状：", result.shape)

np.save('./data/均衡重力_约束反演.npy', result)

# -------------------------------反演结果可视化--------------------------------------------
Fig_xz(100, result[30, :, :].T, 8.88, 1, 'gra', 'upper')
plt.savefig('./figure/卫星重力数据约束反演')

plt.show()
