import numpy as np
from numpy import log, arctan, square, sqrt
import time


class Grids_trad:

    def __init__(self,
                 x_measure_start, x_measure_step, x_measure_end,
                 y_measure_start, y_measure_step, y_measure_end,
                 z_measure_square, z_measure,
                 x_model_start, x_model_step, x_model_end,
                 y_model_start, y_model_step, y_model_end,
                 z_model_start, z_model_step, z_model_end):

        # Define measurement grid on the X and Y axes
        self.x_measure = np.arange(x_measure_start, x_measure_end + 0.001, x_measure_step)
        self.y_measure = np.arange(y_measure_start, y_measure_end + 0.001, y_measure_step)

        self.x_measure_num = len(self.x_measure)
        self.y_measure_num = len(self.y_measure)
        self.measure_num = self.x_measure_num * self.y_measure_num

        # Define model grid on the X, Y, and Z axes
        self.x_model = np.arange(x_model_start, x_model_end + 0.001, x_model_step)
        self.y_model = np.arange(y_model_start, y_model_end + 0.001, y_model_step)
        self.z_model = np.arange(z_model_start, z_model_end + 0.001, z_model_step)

        self.x_model_num = len(self.x_model) - 1
        self.y_model_num = len(self.y_model) - 1
        self.z_model_num = len(self.z_model) - 1
        self.model_num = self.x_model_num * self.y_model_num * self.z_model_num

        # Initialize elevation data if not provided
        self.z_measure_square = np.zeros((self.x_measure_num, self.y_measure_num))
        if z_measure is not None:
            self.z_measure = z_measure
            self.z_measure_square = np.ones((self.x_measure_num, self.y_measure_num)) * z_measure
        elif z_measure_square is not None:
            self.z_measure_square = z_measure_square

        # Convert units to kilometers for all grid dimensions
        self.x_measure /= 1000
        self.y_measure /= 1000
        self.z_measure_square /= 1000
        self.z_measure /= 1000
        self.x_model /= 1000
        self.y_model /= 1000
        self.z_model /= 1000

        self.norm = self.judge_norm()

    def judge_norm(self):
        if self.x_model.all() != self.x_measure.all():
            return False
        if self.y_model.all() != self.y_measure.all():
            return False
        return True


class Core:

    @staticmethod
    def Gxz(xd, yd, zd, r, weight):
        result = log(r - yd)
        try:
            result[np.isnan(result)] = 0
            result[np.isinf(result)] = 0
        except:
            if np.isnan(result) or np.isinf(result):
                result = 0.0
        return result * weight

    @staticmethod
    def Gyz(xd, yd, zd, r, weight):
        result = log(r - xd)
        try:
            result[np.isnan(result)] = 0
            result[np.isinf(result)] = 0
        except:
            if np.isnan(result) or np.isinf(result):
                result = 0.0
        return result * weight

    @staticmethod
    def Gzz(xd, yd, zd, r, weight):
        result = arctan(xd * yd / r / zd)
        try:
            result[np.isnan(result)] = 0
            result[np.isinf(result)] = 0
        except:
            if np.isnan(result) or np.isinf(result):
                result = 0.0
        return result * weight

    @staticmethod
    def dg(xd, yd, zd, r, weight):
        result = xd * Core.Gxz(xd, yd, zd, r, weight)
        result += yd * Core.Gyz(xd, yd, zd, r, weight)
        result += zd * Core.Gzz(xd, yd, zd, r, weight)
        return result


G0 = 6.67259


class Sensitivity:
    def __init__(self, Grids):

        self.compute_sensitivity_base(Grids)

    def compute_sensitivity_base(self, Grids):

        s_temp1 = np.zeros((Grids.x_model_num + 1, Grids.y_model_num + 1, Grids.z_model_num + 1))
        for i in range(Grids.x_model_num + 1):
            for j in range(Grids.y_model_num + 1):
                for k in range(Grids.z_model_num + 1):
                    xd = Grids.x_model[i]
                    yd = Grids.y_model[j]
                    zd = Grids.z_model[k] - Grids.z_measure
                    r = np.sqrt(xd ** 2 + yd ** 2 + zd ** 2)
                    s_temp1[i, j, k] = Core.dg(xd, yd, zd, r, weight=1)

        s_temp2 = np.zeros((Grids.x_model_num, Grids.y_model_num, Grids.z_model_num))
        s_temp2 = s_temp1[1:, 1:, 1:] \
                  + s_temp1[0:-1, 0:-1, 1:] \
                  + s_temp1[0:-1, 1:, 0:-1] \
                  + s_temp1[1:, 0:-1, 0:-1] \
                  - s_temp1[0:-1, 1:, 1:] \
                  - s_temp1[1:, 0:-1, 1:] \
                  - s_temp1[1:, 1:, 0:-1] \
                  - s_temp1[0:-1, 0:-1, 0:-1]

        del s_temp1

        s_temp2_flipr = np.fliplr(s_temp2)
        s_flipr = np.concatenate((s_temp2_flipr, s_temp2), axis=1)
        del s_temp2_flipr, s_temp2

        s_flipud = np.flipud(s_flipr)
        self.sensitivity_base = np.concatenate((s_flipud, s_flipr), axis=0)
        self.sensitivity_base = self.sensitivity_base * G0

        del s_flipud, s_flipr

        self.xmid = Grids.x_model_num
        self.ymid = Grids.y_model_num
        self.xlen = 2 * self.xmid
        self.ylen = 2 * self.ymid

        return None

    def extract_sensitivity_by_measure(self, index_x, index_y):

        # print('self.sensitivity_base', self.sensitivity_base.shape)
        sensivity_single_measure_point \
            = self.sensitivity_base \
            [ \
              (self.xmid - index_x):(self.xlen - index_x), \
              (self.ymid - index_y):(self.ylen - index_y), \
              : \
              ]
        return sensivity_single_measure_point


class Model_trad:
    def __init__(self, Grids):
        # ---------------------------------------------------------------------------------------------
        self.Grids = Grids
        self.nx, self.ny, self.nz = Grids.x_model_num, Grids.y_model_num, Grids.z_model_num
        self.property = np.zeros((Grids.x_model_num, Grids.y_model_num, Grids.z_model_num))
        self.anomaly = np.zeros((Grids.x_measure_num, Grids.y_measure_num))
        self.Sensitivity = Sensitivity(Grids)
        # ---------------------------------------------------------------------------------------------

    def forward(self):

        for i in range(self.Grids.x_measure_num):
            for j in range(self.Grids.y_measure_num):
                sensitivity = self.Sensitivity.extract_sensitivity_by_measure(i, j)
                self.anomaly[i, j] = np.sum(sensitivity * self.property)

        return None

    def iter_grad0(self, data_measure, m_property, m_ref, Ww, We, alpha):

        loss = 0
        self.grad = np.zeros((self.nx, self.ny, self.nz))
        self.W_model = np.zeros((self.nx, self.ny, self.nz))

        for i in range(self.Grids.x_measure_num):
            for j in range(self.Grids.y_measure_num):
                sensitivity = self.Sensitivity.extract_sensitivity_by_measure(i, j)
                d_err = np.sum(sensitivity * m_property) - data_measure[i, j]
                loss = loss + (d_err**2)
                self.grad = self.grad + sensitivity * d_err
                self.W_model = self.W_model + sensitivity * sensitivity

        self.W_model = self.W_model**0.5*Ww
        self.grad = self.grad/(self.W_model*We) + alpha*self.W_model*We*(m_property-m_ref)
        Loss = np.sqrt(loss/((self.nx+1)*(self.ny+1)))

        return self.grad, self.W_model, loss, Loss

    def iter_grad(self, data_measure, m_property, m_ref, W_height, We, alpha):

        loss = 0
        self.grad = np.zeros((self.nx, self.ny, self.nz))
        for i in range(self.Grids.x_measure_num):
            for j in range(self.Grids.y_measure_num):
                sensitivity = self.Sensitivity.extract_sensitivity_by_measure(i, j)
                d_err = np.sum(sensitivity * m_property) - data_measure[i, j]
                loss = loss + (d_err ** 2)
                self.grad = self.grad + sensitivity * d_err
                self.W_model = self.W_model + sensitivity * sensitivity

        self.grad = self.grad / (W_height*We) + alpha * W_height * We*(m_property - m_ref)

        loss = np.sqrt(loss / ((self.nx + 1) * (self.ny + 1)))

        return self.grad, loss

    def iter_t_down(self, p, Wm, We, alpha):

        vector = np.zeros((self.nx+1, self.ny+1))
        for i in range(self.Grids.x_measure_num):
            for j in range(self.Grids.y_measure_num):
                sensitivity = self.Sensitivity.extract_sensitivity_by_measure(i, j)
                vector[i, j] = np.sum(sensitivity*p/Wm/We)

        t_down = np.sum(vector**2)+alpha*np.sum(p**2)

        return t_down


if __name__ == "__main__":

    import time
    import matplotlib.pyplot as plt
    from Tool.Fig_2D import Fig_xy

    # ---------------------------开始正演计算---------------------------------------------
    t1 = time.time()

    GraModel = Grids_trad(0, 100, 100*100,
                          0, 100, 100*100,
                          None, 0,
                          0, 100, 100*100,
                          0, 100, 100*100,
                          0, 100, 2000)

    model = Model_trad(GraModel)
    model.property[50:60, 50:60, 10:20] = 1

    model.forward()

    # 结束计时
    t2 = time.time()
    print("正演耗时：", t2 - t1)
    # ---------------------------结束正演计算---------------------------------------------

    print('模型规模量：', model.property.shape)
    print('model.anomaly.shape = ', model.anomaly.shape)
    print('max = ', model.anomaly.max())
    print('min = ', model.anomaly.min())

    # ---------------------------可视化---------------------------------------------
    Fig_xy(100, model.anomaly, 0.1, 0.1, 'mGal', 0)

    # plt.savefig('./figure/gra_1_anomaly', dpi=300)

    plt.show()
