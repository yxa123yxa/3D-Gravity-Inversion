import numpy as np
import matplotlib.pyplot as plt
from Tool.Fig_3D import voxel
from Tool.Fig_2D import Fig_xz, Fig_xy
from Tool.Grid import grid_data


def build_3d_initial_model_robust(terrain,
                                  z_top=-3.0,
                                  nz=33,
                                  dz=1.0,
                                  rho_rock=2.67,
                                  auto_unit_check=True,
                                  invert_sign=False):
    """
    更鲁棒的地形下方填充函数（仅填充地形以下为 rho_rock）
    Inputs:
      terrain: (161,111) 节点式地形数组。期望单位 km，z 向下为正（海底为正，陆地为负）。
               函数会尝试做自动单位检测（m -> km）和符号检测（如需要可通过 invert_sign 修正）。
      z_top: 模型顶部 z（km），例如 -3.0
      nz, dz: 垂直层数量与层厚（km）
      rho_rock: 填充值（例如 2.67）
      auto_unit_check: 是否自动把以米为单位的 terrain 转成 km（默认 True）
      invert_sign: 如果你的 terrain 方向跟期望相反（z 向上为正），设置 True 即可翻转符号

    Returns:
      densities: (160,110,nz) np.float32
      z_centers: (nz,) layer center depths (km)
      terrain_cell: (160,110) cell-centered terrain (km)
      info: dict 包含诊断信息（min/max 原始/处理后，unit_converted, sign_inverted）
    """

    info = {"orig_min": float(np.nanmin(terrain)), "orig_max": float(np.nanmax(terrain))}

    if auto_unit_check:
        # 如果最大值绝对值很大（比如 > 100），很可能是以米为单位 -> 转成 km
        if abs(info["orig_max"]) > 100 or abs(info["orig_min"]) > 100:
            terrain = terrain.astype(float) / 1000.0
            info["unit_converted"] = True
        else:
            info["unit_converted"] = False
    else:
        info["unit_converted"] = False

    # 可选翻转符号（如果用户知道数据和约定方向相反）
    if invert_sign:
        terrain = -terrain
        info["sign_inverted_by_user"] = True
    else:
        info["sign_inverted_by_user"] = False

    info["proc_min"] = float(np.nanmin(terrain)); info["proc_max"] = float(np.nanmax(terrain))

    # 计算 cell-centered terrain (160,110)
    terrain_cell = 0.25 * (terrain[:-1, :-1] + terrain[1:, :-1] + terrain[:-1, 1:] + terrain[1:, 1:])
    nx, ny = terrain_cell.shape  # should be (160,110)

    # 垂直层中心
    z_centers = np.array([z_top + (k + 0.5) * dz for k in range(nz)], dtype=float)

    # 初始化密度
    densities = np.zeros((nx, ny, nz), dtype=np.float32)

    # 向量化填充：当层中心 >= terrain_cell 时填充（层中心更深）
    # 使用广播，把 terrain_cell 形状扩展为 (nx,ny,1) 以便与 z_centers 比较
    terrain_exp = terrain_cell[:, :, np.newaxis]        # (nx,ny,1)
    zc_exp = z_centers[np.newaxis, np.newaxis, :]       # (1,1,nz)
    mask_below = (zc_exp >= terrain_exp)                # True 表示该层中心位于/下于地形 -> 填充

    densities[mask_below] = rho_rock

    # 诊断信息：每层被填充百分比
    total_cells = nx * ny
    filled_counts = mask_below.sum(axis=(0,1))  # length nz
    filled_pct = (filled_counts / total_cells) * 100.0

    info.update({
        "nx": int(nx), "ny": int(ny), "nz": int(nz),
        "z_top": float(z_top), "dz": float(dz),
        "rho_rock": float(rho_rock),
        "filled_counts_per_layer": filled_counts.tolist(),
        "filled_pct_per_layer": filled_pct.tolist(),
        "z_centers": z_centers.tolist()
    })

    return densities, z_centers, terrain_cell, info


# ----------------------------------------------------------------------

terrain_data = np.loadtxt('../data/landform_76_64_obs.txt')
terrain = -grid_data(terrain_data)
print(terrain.shape)
densities_f, zc_, terrain_cell_, info_ = build_3d_initial_model_robust(terrain, z_top=-3.0, nz=33, dz=1.0, rho_rock=1, auto_unit_check=True, invert_sign=False)
print(densities_f.shape)

np.save('../data/映射模型.npy', densities_f)
# ----------------------------------------------------------------------

densities, zc, terrain_cell, info = build_3d_initial_model_robust(terrain, z_top=-3.0, nz=33, dz=1.0, rho_rock=0.02, auto_unit_check=True, invert_sign=False)
print(densities_f.shape)
fuchongdai_up  = np.loadtxt('../data/俯冲带上界面.txt')
fuchongdai_up = grid_data(fuchongdai_up)+3
print(fuchongdai_up.shape)

tol = 1e-4
for i in range(75):
    for j in range(62):
        iz1 = int(np.floor(fuchongdai_up[i, j]))
        iz2 = iz1+10

        # 陆壳
        # vals = densities[i, j, :18]
        # mask = np.abs(vals) >= tol   # mask: 找出那些不是接近0的点
        # vals[mask] = -0.01

        # 陆壳地幔
        # vals = densities[i, j, 18:iz1]
        # mask = np.abs(vals) >= tol  # mask: 找出那些不是接近0的点
        # vals[mask] = 0.05

        # 俯冲带
        vals = densities[i, j, iz1:iz2]
        mask = np.abs(vals) >= tol  # mask: 找出那些不是接近0的点
        vals[mask] = -0.2


# ---------------------导入俯冲带信息----------------------------------------

np.save('../data/初始模型.npy', densities)

Ww = np.ones((75, 62, 33))
Ww[np.isclose(densities, -0.2, atol=1e-6)] = 10
np.save('../data/权重矩阵.npy', Ww)

# ----------------------------------------------------------------------------

Nx, Ny, Nz = densities.shape

dx = 4.44  # km
dy = 4.44  # km
dz = 1.0   # km

# 构建坐标轴
y = np.arange(0, Ny*dy, dy)  # km
z = np.arange(-3, -3 + Nz*dz, dz)  # km

slice_xz = densities[30, :, :]  # shape Nx×Nz

plt.figure(figsize=(10, 2))
# 设置 extent 让坐标正确
plt.imshow(
    densities[40, :, :].T,
    extent=[y.min(), y.max(), z.max(), z.min()],
    aspect='auto',
    interpolation='bicubic',
    cmap='jet',
    origin='upper'
)

plt.colorbar(label='Density (g/cm³)')
plt.xlabel('Y (km)')
plt.ylabel('Depth Z (km)')

plt.figure(figsize=(10, 2))
# 设置 extent 让坐标正确
plt.imshow(
    densities[60, :, :].T,
    extent=[y.min(), y.max(), z.max(), z.min()],
    aspect='auto',
    interpolation='bicubic',
    cmap='jet',
    origin='upper'
)

plt.colorbar(label='Density (g/cm³)')
plt.xlabel('Y (km)')
plt.ylabel('Depth Z (km)')

plt.show()
