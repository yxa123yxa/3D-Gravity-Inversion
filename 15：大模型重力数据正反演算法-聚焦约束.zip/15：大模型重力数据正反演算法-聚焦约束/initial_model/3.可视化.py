import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import zoom, gaussian_filter

# =========================================================
# 1. 读取数据
# =========================================================
model = np.load("../data/均衡重力_约束反演.npy")
model_control = np.load("../data/映射模型.npy")

print("original shape:", model.shape, model_control.shape)

# =========================================================
# 2. 掩膜控制（空气层 -> NaN）
# =========================================================
Model = model * model_control
Model = Model.astype(float)
Model[Model == 0] = np.nan

# =========================================================
# 3. 插值参数（物理尺度）
# =========================================================
dx = dy = 8880.0
dz = 1000.0

target_xy = 2220.0
target_z  = 1000.0

zoom_factors = (dx/target_xy, dy/target_xy, dz/target_z)

# =========================================================
# 4. 插值（禁止 NaN 参与）
# =========================================================
Model_interp = Model.copy()
Model_interp[np.isnan(Model_interp)] = 0.0

model_iso = zoom(
    Model_interp,
    zoom=zoom_factors,
    order=3,
    mode='nearest'
)

control_iso = zoom(
    model_control,
    zoom=zoom_factors,
    order=0
)

# 恢复空气层
model_iso[control_iso == 0] = np.nan

print("interpolated shape:", model_iso.shape)

# =========================================================
# 5. 三维平滑 + 边界圆滑（核心修改）
# =========================================================

# 1 = 地下，0 = 空气
mask_valid = (~np.isnan(model_iso)).astype(float)

# 临时填充 NaN
data = model_iso.copy()
data[np.isnan(data)] = 0.0

# 各向异性平滑尺度（单位：网格数）
sigma = (1.2, 1.2, 0.8)

# 平滑物性
data_smooth = gaussian_filter(
    data,
    sigma=sigma,
    mode='nearest'
)

# 平滑掩膜（关键）
mask_smooth = gaussian_filter(
    mask_valid,
    sigma=sigma,
    mode='nearest'
)

# 用平滑后的掩膜恢复空气层（圆滑边界）
threshold = 0.5
data_smooth[mask_smooth < threshold] = np.nan

# =========================================================
# 6. 可视化（Y–Z 剖面，固定 x = 60，带物理坐标）
# =========================================================
x_idx = 60

# ---------------- 物理坐标参数 ----------------
dy_km = 2.0     # Y 方向间隔 (km)
dz_km = 1.0     # Z 方向间隔 (km)
z0_km = -3.0    # Z 起点 (km)

ny = data_smooth.shape[1]
nz = data_smooth.shape[2]

y_min = 0.0
y_max = ny * dy_km

z_min = z0_km
z_max = z0_km + nz * dz_km

extent = [
    y_min, y_max,   # Y 轴
    z_max, z_min    # Z 轴（向下为正）
]

# ---------------- 颜色映射 ----------------
cmap = plt.cm.jet.copy()
cmap.set_bad('white')

plt.figure(figsize=(12, 3))
plt.imshow(
    data_smooth[x_idx, :, :].T,
    cmap=cmap,
    origin='upper',
    aspect='auto',
    interpolation='bicubic',
    extent=extent
)

plt.title('After smoothing (boundary rounded)')
plt.xlabel('Y (km)')
plt.ylabel('Depth (km)')
plt.colorbar(label='Density / Susceptibility')

plt.tight_layout()
plt.savefig('../figure/xunland_卫星数据反演结果.png', dpi=600)
plt.show()
