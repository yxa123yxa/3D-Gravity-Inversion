import numpy as np
import matplotlib.pyplot as plt
from Tool.Fig_3D import voxel
from Tool.Fig_2D import Fig_xz, Fig_xy
from Tool.Grid import grid_data
from Tool.Observe import observe_data
from scipy.interpolate import Rbf


def re_grid_data(data, x_interval, y_interval):
    # data = np.loadtxt(path)
    # data = pd.read_csv(path)
    arr = np.array(data)
    print(arr.shape)
    n = arr.shape[0]
    x = np.zeros(n)
    y = np.zeros(n)
    z = np.zeros(n)
    for i in range(n):
        x[i] = arr[i][0]
        y[i] = arr[i][1]
        z[i] = arr[i][2]

    delta_x = x.max() - x.min()
    delta_y = y.max() - y.min()

    print('x方向全长', delta_x)
    print('y方向全长',  delta_y)

    x = (x - x.min())
    y = (y - y.min())
    n_x = int((delta_x) / x_interval + 1)
    n_y = int((delta_y) / y_interval + 1)
    X = np.linspace(0, delta_x, n_x)
    Y = np.linspace(0, delta_y, n_y)

    # x = (x - x.min())
    # y = (y - y.min())
    # n_x = int((10) / x_interval + 1)
    # n_y = int((5) / y_interval + 1)
    # X = np.linspace(10, 20, n_x)
    # Y = np.linspace(15, 20, n_y)

    X, Y = np.meshgrid(X, Y)

    func = Rbf(x, y, z, function='linear')
    result = func(X, Y)

    return result


# ----------------------------------------------------------------------------
fuchongdai_up = np.loadtxt('../data/复制俯冲带上界面_改进版4.dat')
fuchongdai_up = grid_data(fuchongdai_up)
print(fuchongdai_up.shape)
fuchongdai = fuchongdai_up[35:96, 54:105]

data1 = observe_data(11100, 11100, fuchongdai)

data2 = re_grid_data(data1, 8880, 8880).T
print(data2.shape)

data3 = observe_data(8880, 8880, data2)
print(data3.shape)

np.savetxt('../data/俯冲带上界面.txt', data3)

Fig_xy(100, fuchongdai_up, 11.1, 11.1, 'upper', 1)
Fig_xy(200, data2, 8.88, 8.88, 'upper', 1)

plt.show()
