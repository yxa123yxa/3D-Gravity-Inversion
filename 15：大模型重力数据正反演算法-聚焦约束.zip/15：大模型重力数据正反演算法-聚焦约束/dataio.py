import numpy as np


class loader:

    def __init__(self, path, Flag='m', ext=None):

        data = np.loadtxt(path)

        data[:, 0] = (data[:, 0] - np.min(data[:, 0]))
        data[:, 1] = (data[:, 1] - np.min(data[:, 1]))

        data[:, 0] = np.around(data[:, 0], decimals=3)
        data[:, 1] = np.around(data[:, 1], decimals=3)

        if Flag == 'km':
            data[:, 0] *= 1000
            data[:, 1] *= 1000

        if int(np.around(data[1, 1] - data[2, 1])) == 0:

            self.x_start = 0
            self.x_step = data[2, 0] - data[1, 0]
            self.x_end = np.max(data[:, 0])

            for i in range(len(data)):

                if i != 0 and int(data[i, 0]) == 0:
                    self.x_num = i
                    break

            self.y_start = 0
            self.y_step = data[self.x_num + 1, 1] - data[0, 1]
            self.y_end = np.max(data[:, 1])
            self.y_num = int(np.around(self.y_end / self.y_step + 1))

        if int(np.around(data[2, 0] - data[1, 0])) == 0:

            self.y_start = 0
            self.y_step = data[2, 1] - data[1, 1]
            self.y_end = np.max(data[:, 1])


            for i in range(len(data)):

                if i != 0 and int(data[i, 1]) == 0:
                    self.y_num = i
                    break

            self.x_start = 0
            self.x_step = data[self.y_num + 1, 0] - data[0, 0]
            self.x_end = np.max(data[:, 0])

            self.x_num = int(np.around(self.x_end / self.x_step + 1))

        self.X = np.zeros((self.x_num, self.y_num))
        self.Y = np.zeros((self.x_num, self.y_num))
        self.data = np.zeros((self.x_num, self.y_num))

        for i in range(len(data)):
            x_count = abs(int(np.around(data[i, 0] / self.x_step)))
            y_count = abs(int(np.around(data[i, 1] / self.y_step)))
            self.X[x_count, y_count] = data[i, 0]
            self.Y[x_count, y_count] = data[i, 1]
            self.data[x_count, y_count] = data[i, 2]

        # if ext is not None or ext != 0:
        #     x_num = len(range(0, self.data.shape[0], ext))
        #     y_num = len(range(0, self.data.shape[1], ext))
        #     num = x_num * y_num
        #
        #     self.Xe = np.zeros((self.x_num, self.y_num))
        #     self.Ye = np.zeros((self.x_num, self.y_num))
        #     self.datae = np.zeros((self.x_num, self.y_num))
        #
        #     x_count = 0
        #     y_count = 0
        #     for i in range(0, self.data.shape[0], ext):
        #         y_count = 0
        #         for j in range(0, self.data.shape[1], ext):
        #             self.Xe[x_count, y_count] = self.X[i, j]
        #             self.Ye[x_count, y_count] = self.Y[i, j]
        #             self.datae[x_count, y_count] = self.data[i, j]
        #             y_count += 1
        #         x_count += 1
